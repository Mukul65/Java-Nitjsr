package LAB_Assignment_6_Q3;

public interface LinearDS {

    int MAXSIZE = 100;

    void add(int data);

    int remove();

    void displayElement();

}
