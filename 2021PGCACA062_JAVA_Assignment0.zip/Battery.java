import java.util.Scanner;
public class Battery{
    private float b;
    public Battery() {
        System.out.println("This is a Default constructor");
        b = 100f;
    }
    public void showLevel() {
        System.out.println("Battery level is: "+b);
    }
    public void sendMsg() {
        b -= 2;
    }
    public void recvMsg() {
        b -= 1;
    }
    public void compute() {
        b -= (1.5);
    }
    public void recharge(float min) {
        float m = min/2;
        b += m;
    }
    public static void main(String[] args) {
        Battery as2 = new Battery();
        int t = 10;
        while(t > 0) {
            System.out.print("1. Show battery level\n2. Send message\n3. Receive Message.");
            System.out.print("\n4. Compute.\n5. Recharge\n6. Exit\n");
            Scanner in = new Scanner(System.in);
            System.out.print("Enter your choice: ");
            int c = in.nextInt();
            switch(c) {
                case 1:
                    as2.showLevel();
                    break;
                case 2:
                    as2.sendMsg();
                    break;
                case 3:
                    as2.recvMsg();
                    break;
                case 4:
                    as2.compute();
                    break;
                case 5:
                    System.out.print("Enter the amount of minute you plug the device: ");
                    int min = in.nextInt();
                    as2.recharge(c);
                    break;
                case 6:
                    System.exit(0);
                    break;
            }
        }
    }
}