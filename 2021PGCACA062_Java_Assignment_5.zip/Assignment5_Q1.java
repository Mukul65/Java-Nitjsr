//2021PGCACA062 Program1

import java.util.*;

class Assignment5_Q1 {

    public static void main(String args[]) {
        Scanner A5_1 = new Scanner(System.in);
        int size;

        //negative Array size exception
        try {
            System.out.println("Enter the size of the Array: ");
            size = A5_1.nextInt();
            if (size < 0) {
                throw (new NegativeArraySizeException("Passed the Negative Array index"));
            }
        } catch (NegativeArraySizeException negativeSize) {
            System.out.println(negativeSize);
        }

        int arr[] = new int[5];

        //Array out of bound exception
        try {
            int index;

            System.out.println("Enter the index to peek");
            index = A5_1.nextInt();
            int a = arr[index];

            System.out.println("Value at " + index + " is = " + a);
        } catch (ArrayIndexOutOfBoundsException arrExp) {
            System.out.println(arrExp);
        }

        //IndexOut of bound exception
        try {
            String str;
            System.out.println("Enter a string");
            str = A5_1.next();

            System.out.println("Enter the index to be peeked");
            int index;
            index = A5_1.nextInt();

            char ch = str.charAt(index);
            System.out.println("Character at index " + index + " is: " + ch);
        } catch (IndexOutOfBoundsException indexOutBndExc) {
            System.out.println(indexOutBndExc);
        }

        //Interrupted Exception
        try {
            throw new InterruptedException("Interrupted occured in the process");
        } catch (InterruptedException interExp) {
            System.out.println(interExp);
        }

        //Illegal ArgumentException
        try {
            throw new IllegalArgumentException(
                    "Passed Illegal Argument to the function"
            );
        } catch (IllegalArgumentException illegalExp) {
            System.out.println(illegalExp);
        }

        //Null Pointer Exception
        try {
            throw new NullPointerException("Null pointer exception occured");
        } catch (NullPointerException nullPntrExp) {
            System.out.println(nullPntrExp);
        }

        //Illegal Access Exception

        try {
            throw new IllegalAccessException("Illegal Excess Exception Occurred");
        } catch (IllegalAccessException illegealExp) {
            System.out.println(illegealExp);
        }
    }
}